# Databricks notebook source
# MAGIC %md
# MAGIC # Business Scenario

# COMMAND ----------

# MAGIC %md
# MAGIC A global retail organization collects customer profile updates from multiple operational
# MAGIC systems. Whenever a customer is created or updated, the source systems emit Change Data
# MAGIC Capture (CDC) events.
# MAGIC These events are delivered as JSON files into cloud storage in near real-time.
# MAGIC The data engineering team must build a robust pipeline using Databricks and PySpark that
# MAGIC ingests these CDC events, processes them incrementally, and maintains a historical
# MAGIC Customer Dimension table using Slowly Changing Dimension Type 2 (SCD2).
# MAGIC The pipeline must be designed using a Medallion Architecture:
# MAGIC Bronze → Silver → Gold

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Source Data
# MAGIC Incoming JSON CDC events arrive in cloud storage at:
# MAGIC /mnt/raw/customer_updates/
# MAGIC
# MAGIC
# MAGIC Each record represents an event from the operational system.
# MAGIC
# MAGIC Sample Records
# MAGIC
# MAGIC
# MAGIC {&quot;customer_id&quot;:&quot;C101&quot;,&quot;name&quot;:&quot;Rahul
# MAGIC Sharma&quot;,&quot;email&quot;:&quot;rahul@gmail.com&quot;,&quot;city&quot;:&quot;Delhi&quot;,&quot;status&quot;:&quot;ACTIVE&quot;,&quot;operation&quot;:&quot;INSERT&quot;,&quot;
# MAGIC update_ts&quot;:&quot;2026-03-01T09:00:00&quot;}
# MAGIC {&quot;customer_id&quot;:&quot;C102&quot;,&quot;name&quot;:&quot;Priya
# MAGIC Singh&quot;,&quot;email&quot;:&quot;priya@gmail.com&quot;,&quot;city&quot;:&quot;Mumbai&quot;,&quot;status&quot;:&quot;ACTIVE&quot;,&quot;operation&quot;:&quot;INSERT&quot;,&quot;
# MAGIC update_ts&quot;:&quot;2026-03-01T09:05:00&quot;}
# MAGIC {&quot;customer_id&quot;:&quot;C101&quot;,&quot;name&quot;:&quot;Rahul
# MAGIC Sharma&quot;,&quot;email&quot;:&quot;rahul@gmail.com&quot;,&quot;city&quot;:&quot;Bangalore&quot;,&quot;status&quot;:&quot;ACTIVE&quot;,&quot;operation&quot;:&quot;UPDA
# MAGIC TE&quot;,&quot;update_ts&quot;:&quot;2026-03-02T10:00:00&quot;}
# MAGIC {&quot;customer_id&quot;:&quot;C102&quot;,&quot;name&quot;:&quot;Priya
# MAGIC Singh&quot;,&quot;email&quot;:&quot;priya_new@gmail.com&quot;,&quot;city&quot;:&quot;Mumbai&quot;,&quot;status&quot;:&quot;ACTIVE&quot;,&quot;operation&quot;:&quot;UPD
# MAGIC ATE&quot;,&quot;update_ts&quot;:&quot;2026-03-02T10:30:00&quot;}
# MAGIC {&quot;customer_id&quot;:&quot;C101&quot;,&quot;name&quot;:&quot;Rahul
# MAGIC Sharma&quot;,&quot;email&quot;:&quot;rahul@gmail.com&quot;,&quot;city&quot;:&quot;Bangalore&quot;,&quot;status&quot;:&quot;INACTIVE&quot;,&quot;operation&quot;:&quot;UP
# MAGIC DATE&quot;,&quot;update_ts&quot;:&quot;2026-03-03T12:00:00&quot;}

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.window import Window
# from delta.tables import DeltaTable

# COMMAND ----------

# MAGIC %md
# MAGIC # Requirements

# COMMAND ----------

# MAGIC %md
# MAGIC # 1. Bronze Layer
# MAGIC
# MAGIC Build a pipeline that:
# MAGIC
# MAGIC ● Ingests raw CDC JSON data using Auto Loader 
# MAGIC
# MAGIC ● Stores raw records without modification
# MAGIC
# MAGIC ● Adds an ingestion timestamp
# MAGIC
# MAGIC ● Maintains schema evolution support

# COMMAND ----------

 # Auto Loader use format cloudFiles
bronze_df = (
    spark.readStream
    .format("cloudFiles")
    .option("cloudFiles.format", "json")
    .option("cloudFiles.schemaLocation", "/Volumes/datahub01tbusiness/operational/customer_updates/schema/customer/2/")
    .load("/mnt/raw/customers_updates/*/")
)

bronze_df = bronze_df.withColumn("ingestion_ts", current_timestamp())

# Write to Bronze Delta Table
(
    bronze_df.writeStream
    .format("delta")
    .option("checkpointLocation", "/Volumes/datahub01tbusiness/operational/customer_updates/checkpoints/bronze_customer/2/")
    .outputMode("append")
    .trigger(availableNow=True)
    .table("datahub01tbusiness.operational.bronze_customer")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # 2. Silver Layer
# MAGIC
# MAGIC Clean and validate the data.
# MAGIC
# MAGIC Tasks:
# MAGIC
# MAGIC ● Convert update_ts into timestamp format
# MAGIC
# MAGIC ● Remove duplicate CDC events
# MAGIC
# MAGIC ● Validate that customer_id is not null
# MAGIC
# MAGIC ● Ensure operation values are valid:
# MAGIC
# MAGIC INSERT
# MAGIC
# MAGIC UPDATE
# MAGIC
# MAGIC ● Handle late arriving events

# COMMAND ----------

def process_silver(batch_df, batch_id):

    clean_df = (
        batch_df
        .withColumn("update_ts", to_timestamp("update_ts"))
        .filter(col("customer_id").isNotNull())
        .filter(col("operation").isin("INSERT", "UPDATE"))
    )

    # Deduplication
    window_spec = Window.partitionBy("customer_id", "update_ts").orderBy(col("ingestion_ts").desc())

    dedup_df = (
        clean_df
        .withColumn("rn", row_number().over(window_spec))
        .filter(col("rn") == 1)
        .drop("rn")
    )

    dedup_df.write.format("delta").mode("append").saveAsTable("datahub01tbusiness.operational.silver_customer")


bronze_stream = spark.readStream.table("datahub01tbusiness.operational.bronze_customer")

(
    bronze_stream.writeStream
    .foreachBatch(process_silver)
    .option("checkpointLocation", "/Volumes/datahub01tbusiness/operational/customer_updates/checkpoints/silver_customer/2/")
    .trigger(availableNow=True)
    .start()
)

# COMMAND ----------

# MAGIC %md
# MAGIC #3. Gold Layer – Customer Dimension Table
# MAGIC
# MAGIC Create a Slowly Changing Dimension Type 2 table to maintain history.
# MAGIC
# MAGIC The table should contain the following columns:
# MAGIC
# MAGIC customer_sk (surrogate key),
# MAGIC customer_id,
# MAGIC name,
# MAGIC email,
# MAGIC city,
# MAGIC status,
# MAGIC start_date,
# MAGIC end_date,
# MAGIC is_current

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS datahub01tbusiness.operational.gold_customer (
# MAGIC     customer_sk BIGINT GENERATED ALWAYS AS IDENTITY,
# MAGIC     customer_id STRING,
# MAGIC     name STRING,
# MAGIC     email STRING,
# MAGIC     city STRING,
# MAGIC     status STRING,
# MAGIC     start_date DATE,
# MAGIC     end_date DATE,
# MAGIC     is_current BOOLEAN
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %md
# MAGIC # 4. SCD Type 2 Logic
# MAGIC
# MAGIC Implement the following logic:
# MAGIC ### New Customer
# MAGIC Insert a new record with:
# MAGIC start_date = update_ts,
# MAGIC end_date = NULL
# MAGIC
# MAGIC is_current = true
# MAGIC ### Customer Update
# MAGIC When attributes change:
# MAGIC 1. Close previous record
# MAGIC end_date = update_ts,
# MAGIC is_current = false
# MAGIC 2. Insert new record
# MAGIC start_date = update_ts,
# MAGIC is_current = true
# MAGIC
# MAGIC ### Additional Constraints
# MAGIC Your solution must handle the following production challenges:
# MAGIC ### Out-of-order events
# MAGIC
# MAGIC Events may arrive late.
# MAGIC
# MAGIC Example:
# MAGIC update_ts = 2026-03-01
# MAGIC arrives after
# MAGIC update_ts = 2026-03-02
# MAGIC
# MAGIC Your pipeline must still produce correct history.
# MAGIC
# MAGIC ### Duplicate CDC events
# MAGIC
# MAGIC Example
# MAGIC duplicates may occur:
# MAGIC (customer_id , update_ts)
# MAGIC
# MAGIC Duplicates must be removed.
# MAGIC
# MAGIC ### Incremental processing
# MAGIC
# MAGIC The pipeline must:
# MAGIC
# MAGIC ● Avoid full table recomputation
# MAGIC
# MAGIC ● Process only new CDC events

# COMMAND ----------


def upsert_gold(batch_df, batch_id):

    # Step 1: Clean + Cast timestamp
    df = (
        batch_df
        .withColumn("update_ts", to_timestamp("update_ts"))
        .select("customer_id","name","email", "city", "status", "update_ts")
    )

    # Step 2: Window ONLY on customer_id (IMPORTANT FIX)
    window_spec = Window.partitionBy("customer_id").orderBy("update_ts")

    # Step 3: Detect changes using LAG
    df = (
        df
        .withColumn("prev_city", lag("city").over(window_spec))
        .withColumn("prev_status", lag("status").over(window_spec))
    )

    # Step 4: Filter only changed records (SCD2 logic)
    df_changes = (
        df
        .withColumn(
            "is_change",
            (col("city") != col("prev_city")) |
            (col("status") != col("prev_status"))
        )
        .filter((col("is_change") == True) | col("prev_city").isNull())
    )

    # Step 5: Create SCD columns
    df_scd = (
        df_changes
        .withColumn("start_date", col("update_ts"))
        .withColumn("end_date", lead("update_ts").over(window_spec))
        .withColumn("is_current", col("end_date").isNull())
        .select("customer_id","name","email", "city", "status", "start_date", "end_date", "is_current")
    )

    # Step 6: Create temp view
    df_scd.createOrReplaceTempView("updates")

    # Step 7: MERGE into Gold table
    spark.sql("""
        MERGE INTO datahub01tbusiness.operational.gold_customer AS target
        USING updates AS source
        ON target.customer_id = source.customer_id
           AND target.start_date = source.start_date

        WHEN MATCHED THEN UPDATE SET
            target.city = source.city,
            target.status = source.status,
            target.end_date = source.end_date,
            target.is_current = source.is_current

        WHEN NOT MATCHED THEN INSERT (
            customer_id,
            name,
            email,
            city,
            status,
            start_date,
            end_date,
            is_current
        )
        VALUES (
            source.customer_id,
            source.name,
            source.email,
            source.city,
            source.status,
            source.start_date,
            source.end_date,
            source.is_current
        )
    """)

# COMMAND ----------

silver_stream = spark.readStream.table("datahub01tbusiness.operational.silver_customer")

(
    silver_stream.writeStream
    .foreachBatch(upsert_gold)
    .option("checkpointLocation", "/Volumes/datahub01tbusiness/operational/customer_updates/checkpoints/gold_customer/2/")
    .trigger(availableNow=True)
    .start()
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Expected Output
# MAGIC ![image_1774530550924.png](./image_1774530550924.png "image_1774530550924.png")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT customer_sk,customer_id,city,status,start_date,end_date,is_current from datahub01tbusiness.operational.gold_customer